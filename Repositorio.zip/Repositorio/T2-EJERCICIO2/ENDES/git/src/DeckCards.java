/* DeckCards es el archivo main y ejecutable que llama al objeto Card 
* Este programa generara un numero determinado de cartas de manera aleatoria.
* Estas indicaran su palo y su valor.
* 
* Se usan la libreria java.lang y la libreria java.util
* 
* Métodos:
* 
* add:(RECIBE:un objeto/DEVUELVE:NADA):Añade un objeto a un arraylist
* get:(RECIBE:una posicion/DEVUELVE:valor guardado en dicho arraylist)obtiene el valor que ocupa un elemento en el array según un valor
* set:(RECIBE:dos posiciones/DEVUELVE:NADA)cambia el valor de un array según dos parámetros
* random:(RECIBE:NADA/DEVUELVE:numero aleatorio multiplicado por contador) crea un valor aleatorio
* size:(RECIBE:un objeto/DEVUELVE:NADA)devuelve el valor de la longitud de un arraylist
* floor:devuelve el valor menor más cercano al valor introducido
* 
*/

import java.util.ArrayList;

public class DeckCards {

	public static void main(String[] args) {

		/*
		 * En esta clase se crean dos Arrays de tipo String, uno sera suits que indicara
		 * el palo de la carta y otro indicara el valor de la misma.
		 */
		String[] suits = { "Spades", "Diamonds", "Club", "Heart" };
		String[] values = { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };

		
		// Se crea el arraylist donde se almacenaran los objetos
		ArrayList<Card> deck = new ArrayList<Card>();

		/**
		 * En este bucle for se crearan 12 cartas por cada palo de la baraja
		 * En el primer bucle for se crearan las doce cartas del primer palo representado 
		 * por i(servira para recorrer el array suits) y sucedera lo mismo con j(recorrera el 
		 * array values mientras i tenga un valor determinado.Luego cambiara el valor de i y se repetira
		 * el proceso.
		 */
		for (int i = 0; i < suits.length; i++) {
			for (int j = 0; j < values.length; j++) {
				Card card = new Card(suits[i], values[j]);
				deck.add(card); 
			}
		}

		
		/**
		 * En este bucle for se les da un valor aleatorio a cada una de las cartas de
		 * la baraja teniendo de referencia el valor de otra carta en la baraja
		 *
		 */
		for (int i = 0; i < deck.size(); i++) {
			int j = (int) Math.floor(Math.random() * i);
			Card tmp = deck.get(i);
			deck.set(i, deck.get(j));
			deck.set(j, tmp);
		}

		// Este bucle for mostrara por pantalla los 10 primeros elementos del arraylist deck
		for (int i = 0; i < 10; i++) {
			System.out.println(deck.get(i));
		}

	}

}
