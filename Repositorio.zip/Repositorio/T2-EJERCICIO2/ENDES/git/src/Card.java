//Card no es un archivo ejecutable ya que efectua de objeto. Este objeto solo declara el objeto
//y devuelve en un metodo to string el palo y el valor de la carta .

public class Card {
	
	/*Explicación del archivo: Este archvio es un objeto que servira para interactuar
	 * con el main.*/

	//Se declaran las variables que van a interactuar con el objeto
	public String suit;
	public String value;
	
	// Se declaran las características del objeto
	public Card (String suit, String value) {
		this.suit = suit;
		this.value = value;
	}
	
	/**
	 * Método to String, que devuelve en una cadena el valor de (suit)y el valor de (value)
	 */
	public String toString () {
		return (this.suit+"-"+this.value);
	}
}
